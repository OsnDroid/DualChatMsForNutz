package com.osndroid.cttms.utils;

import com.alibaba.druid.util.StringUtils;

public class StringEst {

	public static String handle(String ...params)
	{
		return null;
		
	}
	
	public static void main(String[] args) {
		  
	}
}
