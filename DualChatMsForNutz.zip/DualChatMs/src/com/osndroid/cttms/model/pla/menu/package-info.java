/**
 * 
 * 菜单包
 * <p>涉及双信个菜单实体类
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.model.pla.menu;