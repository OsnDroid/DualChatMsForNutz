 
/**
 *
 * 双信平台操作对象
 * <p>此包下包含双信平台多有的操作对象<br><br>
 * {@link com.osndroid.cttms.model.pla.request}双信请求实体类封装
 * {@link com.osndroid.cttms.model.pla.respone}双信响应实体类封装
 * {@link com.osndroid.cttms.model.pla.menu}双信菜单实体类封装
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.model.pla;