/**
 * 
 * http请求信息
 * <p>涉及双信所有请求实体类
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.model.pla.request;