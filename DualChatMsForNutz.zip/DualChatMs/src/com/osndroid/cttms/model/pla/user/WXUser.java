package com.osndroid.cttms.model.pla.user;

import org.nutz.dao.entity.annotation.Table;
import org.nutz.ioc.loader.annotation.IocBean;

/**
 * 
 * @author OsnDroid
 *
 */
@IocBean
@Table("OSN_WECHAT_BIND")
public class WXUser extends User{
	
	

}
