package com.osndroid.cttms.model.pla.user;

import org.nutz.dao.entity.annotation.Table;
import org.nutz.ioc.loader.annotation.IocBean;

/**
 * 
 * @author OsnDroid
 *
 */
@IocBean
@Table("OSN_YIXIN_BIND")
public class YXUser extends User{
 
}
