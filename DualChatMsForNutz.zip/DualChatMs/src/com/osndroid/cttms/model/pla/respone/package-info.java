/**
 * 
 * http响应信息
 * <p>涉及双信所有响应实体类
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.model.pla.respone;