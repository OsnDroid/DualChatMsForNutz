package com.osndroid.cttms.model.pla.menu;

/**
 * 菜单
 * 
 * @author OsnDroid
 *
 */
public class Menu {

	private String name;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}