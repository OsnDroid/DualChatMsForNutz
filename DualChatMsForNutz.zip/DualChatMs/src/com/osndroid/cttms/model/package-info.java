 
/**
 * 
 * 实体对象
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.model;