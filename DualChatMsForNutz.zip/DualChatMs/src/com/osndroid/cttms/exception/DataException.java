package com.osndroid.cttms.exception;

/**
 * 
 * @author OsnDroid
 *
 */
public class DataException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DataException() {
	
	}
	
	public DataException(String arg0) {
		super(arg0);
	}
}
