/**
 * 平台对象组装
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.est;