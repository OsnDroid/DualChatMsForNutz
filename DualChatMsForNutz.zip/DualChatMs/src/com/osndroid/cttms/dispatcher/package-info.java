/**
 * 
 * 消息分发器
 * <p>针对不同消息处理归类
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.dispatcher;