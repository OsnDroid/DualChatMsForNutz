package com.osndroid.cttms.init.config;

/**
 * 
 * @author OsnDroid
 *
 */
public class ServerConfig {
	public static String OPER_MENU_INIT = "/create";
	public static String OPER_MENU_GET = "/get";
	public static String OPER_MENU_DESTROY = "/delete";
}
