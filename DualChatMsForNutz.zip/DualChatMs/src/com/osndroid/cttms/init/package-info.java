/**
 * 
 * 初始化菜单
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.init;