package com.osndroid.cttms.service;

import org.nutz.ioc.loader.annotation.IocBean;

/**
 * 
 * 用户服务
 * @author OsnDroid
 *
 */
@IocBean
public class UserService extends BasicService{

	@Override
	public String handle(String xml, int source) throws Exception {
		return null;
	}
	
	

}
