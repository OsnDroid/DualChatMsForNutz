package com.osndroid.cttms.config;

/**
 * 
 * @author OsnDroid
 *
 */
public class Constants {

	public static final int PAGE_SIZE = 20;
	
}
