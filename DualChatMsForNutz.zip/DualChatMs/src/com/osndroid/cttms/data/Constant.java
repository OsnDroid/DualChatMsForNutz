package com.osndroid.cttms.data;

public class Constant {

	public static final String ENCODING = "utf-8";
}
