/**
 * 
 */
/**
 * @author OsnDroid
 *
 */
package com.osndroid.cttms.data;